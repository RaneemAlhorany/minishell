#include "minishell.h"

int	builtin_exit(t_cmd *cmd)//Exit the shell with an optional status code ///// We will do it later.
{
	(void)cmd;
	return (0);
}
