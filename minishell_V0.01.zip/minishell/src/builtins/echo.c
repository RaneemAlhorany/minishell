#include "minishell.h"

int	builtin_echo(t_cmd *cmd)//Print arguments to standard output, followed by a newline ///// We will do it later.
{
	(void)cmd;
	return (0);
}
