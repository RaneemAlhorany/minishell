#include "minishell.h"

int	builtin_pwd(t_cmd *cmd)//Print the current working directory ///// We will do it later.
{
	(void)cmd;
	return (0);
}
