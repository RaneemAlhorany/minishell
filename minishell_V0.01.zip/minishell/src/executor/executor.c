#include "minishell.h"

int	executor(t_cmd *cmds, char **envp)// Execute commands with proper handling of pipes and redirections///// We will do it later.
{
	(void)cmds;
	(void)envp;
	return (0);
}
