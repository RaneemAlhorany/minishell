#include "minishell.h"

int	handle_pipes(t_cmd *cmds) // Handle pipes between commands ////// We will do it later.
{
	(void)cmds;
	return (0);
}
