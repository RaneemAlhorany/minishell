ما هو الـ Lexer Loop فعلًا؟

الـ lexer loop هو المنسّق
هو لا يفهم:

معنى الأوامر

redirections

pipes

هو فقط:

يمشي على الـ input حرفًا حرفًا
ويحوّله إلى سلسلة Tokens

🎯 هدف الـ lexer loop

يأخذ:

char *input


ويرجع:

t_token *head


حيث head = linked list من التوكنات بالترتيب.

🔁 الفكرة العامة (High Level)

تخيل هذا السيناريو:

echo "hello" | cat >> out.txt


الـ lexer loop يعمل هكذا:

يبدأ من أول input

يتجاهل المسافات

يسأل:

هل هذا operator؟

أم word؟

ينشئ token

يضيفه إلى list

يكرر حتى نهاية السطر

🧩 الأدوات التي لديك (جاهزة)

أنت بنيت كل القطع 👇

✅ أدوات القراءة

skip_spaces(&input)

operator_detection(&input)

word_detection(&input)

✅ أدوات البيانات

create_token

append_token

📌 الـ lexer loop لا يقرأ char بنفسه
بل يستخدم هذه الأدوات فقط.

🧠 ترتيب القرار داخل الـ loop (مهم جدًا)

هذا هو المنطق الذهبي:

في كل دورة:

1️⃣ تجاهل المسافات
2️⃣ إن كان input انتهى → خروج
3️⃣ جرّب operator detection
4️⃣ إن نجح → أضف token → تابع
5️⃣ وإلا → جرّب word_detection
6️⃣ إن فشل → lexer error
7️⃣ إن نجح → أضف token → تابع

📌 operator دائمًا قبل word
لأن:

>> file


لو قرأت word أولًا → كارثة 😄

🚨 متى يعتبر lexer فشل؟

quote غير مغلق

operator غير صالح

word_detection ترجع NULL

في هذه الحالات:

توقف فورًا

نظّف tokens

ترجع NULL أو error flag

🧠 مسؤوليات lexer loop (واضحة جدًا)
✔️ يفعل:

تقسيم input

إنشاء tokens

الحفاظ على الترتيب

❌ لا يفعل:

لا expansion

لا تنفيذ

لا parsing

لا redirection logic

🗺️ شكل الدالة (ذهنيًا فقط)
lexer(input):
    head = NULL

    while (input not end):
        skip_spaces
        if end → break

        if operator detected:
            append token
        else if word detected:
            append token
        else:
            error

    return head