#include "minishell.h"

int	builtin_env(t_cmd *cmd)//Print environment variables ///// We will do it later.
{
	(void)cmd;
	return (0);
}
