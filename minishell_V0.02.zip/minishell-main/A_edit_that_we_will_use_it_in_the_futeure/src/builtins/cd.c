#include "minishell.h"

int	builtin_cd(t_cmd *cmd)//Change the current working directory ///// We will do it later.
{
	(void)cmd;
	return (0);
}
