#include "minishell.h"

int	builtin_unset(t_cmd *cmd)//Unset environment variables ///// We will do it later.
{
	(void)cmd;
	return (0);
}
