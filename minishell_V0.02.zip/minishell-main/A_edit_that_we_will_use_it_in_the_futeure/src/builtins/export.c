#include "minishell.h"

int	builtin_export(t_cmd *cmd)//Export environment variables ///// We will do it later.
{
	(void)cmd;
	return (0);
}
