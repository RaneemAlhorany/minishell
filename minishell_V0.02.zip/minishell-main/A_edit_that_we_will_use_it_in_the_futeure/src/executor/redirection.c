#include "minishell.h"

int	handle_redirections(t_cmd *cmd)//Handle redirections (< > >> <<) ///// We will do it later.
{
	(void)cmd;
	return (0);
}
