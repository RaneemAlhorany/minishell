#include "minishell.h"

void	setup_signals(void)//Signal handling for SIGINT, SIGQUIT 
{
	// TODO
}
